/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsuldeminas.projetodoacaosangue.dao;

import br.edu.ifsuldeminas.projetodoacaosangue.model.DoadorFinanceiro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class DoadorFinanceiroDAO {
    public boolean inserir (DoadorFinanceiro df1) throws ClassNotFoundException{
        Connection conn = Conexao.getConexao();
        String sql = "INSERT INTO doador_financeiro(cpf,data_nascimento,logradouro,bairro,municipio,unidade_federativa,telefone,tipo_doador)"
                + " VALUES (?,?,?,?,?,?,?,?)";
        try{
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1,df1.getCpf());
            pst.setString(2,df1.getData_nascimento());
            pst.setString(3,df1.getLogradouro());
            pst.setString(4,df1.getBairro());
            pst.setString(5,df1.getMunicipio());
            pst.setString(6,df1.getUnidade_federativa());
            pst.setString(7,df1.getTelefone());
            pst.setString(8,df1.getTipo_doador());
            pst.executeUpdate();
            pst.close();
            conn.close();
        }catch(SQLException ex){
            ex.printStackTrace();
        }
       return true; 
    }

    public List<DoadorFinanceiro> consultarPorCpf(String cpf) throws SQLException, ClassNotFoundException {
    List<DoadorFinanceiro> doadores = new ArrayList<>();
    String sql = "SELECT * FROM doador_financeiro WHERE cpf = ?";


    try (PreparedStatement pst = Conexao.getConexao().prepareStatement(sql)) {
        pst.setString(1, cpf);
        ResultSet rs = pst.executeQuery(); 


        while (rs.next()) {
            DoadorFinanceiro doadorf = new DoadorFinanceiro();
            doadorf.setCpf(rs.getString("cpf"));
            doadorf.setData_nascimento(rs.getString("data_nascimento"));
            doadorf.setLogradouro(rs.getString("logradouro"));
            doadorf.setBairro(rs.getString("bairro"));
            doadorf.setMunicipio(rs.getString("municipio"));
            doadorf.setUnidade_federativa(rs.getString("unidade_federativa"));
            doadorf.setTelefone(rs.getString("telefone"));
            doadorf.setTipo_doador(rs.getString("tipo_doador"));

            doadores.add(doadorf);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        throw ex;
    }

    return doadores; 
   }
    }