/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.ifsuldeminas.projetodoacaosangue;

import br.edu.ifsuldeminas.projetodoacaosangue.view.PainelDoacao;
import java.sql.Connection;

/**
 *
 * @author Usuario
 */
public class ProjetoDoacaoSangue {
        
    public static void main(String[] args) {
        PainelDoacao tela = new PainelDoacao();
        tela.setVisible(true);
        
        
    }
    }