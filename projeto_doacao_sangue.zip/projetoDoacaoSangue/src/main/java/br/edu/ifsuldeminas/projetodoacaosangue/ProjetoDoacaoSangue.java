/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.ifsuldeminas.projetodoacaosangue;

/**
 *
 * @author Usuario
 */
public class ProjetoDoacaoSangue {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        //TODO:
        // INTERFACE GRÁFICA
        // CONECTAR COM O BANCO DE DADOS
        // UTILIZAR QUERY PRA CONSULTA DE DADOS
        
    }
}
