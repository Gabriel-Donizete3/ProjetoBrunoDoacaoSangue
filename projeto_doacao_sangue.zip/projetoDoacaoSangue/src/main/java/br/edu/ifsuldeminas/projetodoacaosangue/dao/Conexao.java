/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsuldeminas.projetodoacaosangue.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Usuario
 */
public class Conexao {
    public static Connection getConexao() throws ClassNotFoundException{
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:"
                + "3306/doacao_sangue?zero"
                + "DateTimeBehavior=CONVERT_TO_NULL";
        String usuario = "root";
        String senha = "";
        
        try{
            //garantia de acesso driver em si
            System.out.println("Carregando o Driver...");
            Class.forName(driver);
            //implementando o manager (gerente) do driver
            System.out.println("Driver carregado com sucesso!");
            Connection conexao = DriverManager.getConnection(url,usuario,senha);
            System.out.println("Conexão estabelecida com sucesso!");
            return conexao;
        }catch(SQLException ex){
        }
        return null;
    }
    
    public static void main(String[] args) throws SQLException{
        Connection conn = Conexao.getConexao();
        System.out.println(conn);
    }
}
