/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsuldeminas.projetodoacaosangue.model;

/**
 *
 * @author Usuario
 */
//define as variáveis do objeto e encapsula-as usando private
public class DoadorFinanceiro {
    private int idDoadorFinanceiro;
    private String cpf;
    private String data_nascimento;
    private String logradouro;
    private String bairro;
    private String municipio;
    private String unidade_federativa;
    private String telefone;
    private String tipo_doador;

    //aplica os métodos getters and setters.
    public int getIdDoadorFinanceiro() {
        return idDoadorFinanceiro;
    }

    public void setIdDoadorFinanceiro(int idDoadorFinanceiro) {
        this.idDoadorFinanceiro = idDoadorFinanceiro;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(String data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getUnidade_federativa() {
        return unidade_federativa;
    }

    public void setUnidade_federativa(String unidade_federativa) {
        this.unidade_federativa = unidade_federativa;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getTipo_doador() {
        return tipo_doador;
    }

    public void setTipo_doador(String tipo_doador) {
        this.tipo_doador = tipo_doador;
    }
    
}
