/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsuldeminas.projetodoacaosangue.dao;

import br.edu.ifsuldeminas.projetodoacaosangue.model.DoadorSangue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPlane;

/**
 *
 * @author Usuario
 */
public class DoadorSangueDAO {
    public boolean inserir (DoadorSangue ds1) throws ClassNotFoundException{
        Connection conn = Conexao.getConexao();
        String sql = "INSERT INTO doador_de_sangue(cpf,data_nascimento,logradouro,bairro,municipio,unidade_federativa,telefone,tipo_sanguineo,peso_kg)"
                + " VALUES (?,?,?,?,?,?,?,?,?)";
        try{
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1,ds1.getCpf());
            pst.setString(2,ds1.getData_nascimento());
            pst.setString(3,ds1.getLogradouro());
            pst.setString(4,ds1.getBairro());
            pst.setString(5,ds1.getMunicipio());
            pst.setString(6,ds1.getUnidade_federativa());
            pst.setString(7,ds1.getTelefone());
            pst.setString(8,ds1.getTipo_sanguineo());
            pst.setString(9,ds1.getPeso_kg());
            pst.executeUpdate();
            pst.close();
            conn.close();
            JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso!");
        }catch(SQLException ex){
            ex.printStackTrace();
        }
       return true; 
    }
//Lista gerada para consulta de dados para o comprovante do doador de sangue, utilizando como informação principal o CPF
    public List<DoadorSangue> consultarPorCpf(String cpf) throws SQLException, ClassNotFoundException {
    List<DoadorSangue> doadores = new ArrayList<>();
    String sql = "SELECT * FROM doador_de_sangue WHERE cpf = ?";


    try (PreparedStatement pst = Conexao.getConexao().prepareStatement(sql)) {
        pst.setString(1, cpf);
        ResultSet rs = pst.executeQuery(); 


        while (rs.next()) {
            DoadorSangue doadors = new DoadorSangue();
            doadors.setIdDoadorSangue(rs.getInt("idDoadorSangue"));
            doadors.setCpf(rs.getString("cpf"));
            doadors.setData_nascimento(rs.getString("data_nascimento"));
            doadors.setLogradouro(rs.getString("logradouro"));
            doadors.setBairro(rs.getString("bairro"));
            doadors.setMunicipio(rs.getString("municipio"));
            doadors.setUnidade_federativa(rs.getString("unidade_federativa"));
            doadors.setTelefone(rs.getString("telefone"));
            doadors.setTipo_sanguineo(rs.getString("tipo_sanguineo"));
            doadors.setPeso_kg(rs.getString("peso_kg"));

            doadores.add(doadors);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        throw ex;
    }

    return doadores; 
   }
    //Lista gerada para consulta de dados para o comprovante do doador de sangue, utilizando como informação principal o ID
    public List<DoadorSangue> consultarPorId(String id) throws SQLException, ClassNotFoundException {
    List<DoadorSangue> doadores = new ArrayList<>();
    String sql = "SELECT * FROM doador_de_sangue WHERE idDoadorSangue = ?";
    
    
    try (PreparedStatement pst = Conexao.getConexao().prepareStatement(sql)) {
        pst.setString(1, id);
        ResultSet rs = pst.executeQuery(); 


        while (rs.next()) {
            DoadorSangue doadors = new DoadorSangue();
            doadors.setIdDoadorSangue(rs.getInt("idDoadorSangue"));
            doadors.setCpf(rs.getString("cpf"));
            doadors.setData_nascimento(rs.getString("data_nascimento"));
            doadors.setLogradouro(rs.getString("logradouro"));
            doadors.setBairro(rs.getString("bairro"));
            doadors.setMunicipio(rs.getString("municipio"));
            doadors.setUnidade_federativa(rs.getString("unidade_federativa"));
            doadors.setTelefone(rs.getString("telefone"));
            doadors.setTipo_sanguineo(rs.getString("tipo_sanguineo"));
            doadors.setPeso_kg(rs.getString("peso_kg"));

            doadores.add(doadors);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        throw ex;
    }
    return doadores;
    }
}
    
    


