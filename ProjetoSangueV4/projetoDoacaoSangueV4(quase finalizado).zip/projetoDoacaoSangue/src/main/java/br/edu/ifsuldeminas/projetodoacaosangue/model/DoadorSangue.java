/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsuldeminas.projetodoacaosangue.model;

/**
 *
 * @author Usuario
 */

//define as variáveis do objeto e encapsula-as usando private
public class DoadorSangue {
    private int idDoadorSangue;
    private String cpf;
    private String data_nascimento;
    private String logradouro;
    private String bairro;
    private String municipio;
    private String unidade_federativa;
    private String telefone;
    private String tipo_sanguineo;
    private String peso_kg;

  

    
    //aplica os métodos getters and setters.
    public int getIdDoadorSangue() {
        return idDoadorSangue;
    }

    public void setIdDoadorSangue(int idDoadorSangue) {
        this.idDoadorSangue = idDoadorSangue;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(String data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getUnidade_federativa() {
        return unidade_federativa;
    }

    public void setUnidade_federativa(String unidade_federativa) {
        this.unidade_federativa = unidade_federativa;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getTipo_sanguineo() {
        return tipo_sanguineo;
    }

    public void setTipo_sanguineo(String tipo_sanguineo) {
        this.tipo_sanguineo = tipo_sanguineo;
    }

    public String getPeso_kg(){
        return peso_kg;
    }

    public void setPeso_kg(String peso_kg) {
        this.peso_kg = peso_kg;
    }



    
}
