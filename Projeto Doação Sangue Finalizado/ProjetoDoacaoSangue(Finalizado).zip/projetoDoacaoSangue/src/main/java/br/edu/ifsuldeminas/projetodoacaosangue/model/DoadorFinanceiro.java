/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifsuldeminas.projetodoacaosangue.model;

/**
 *
 * @author Usuario
 */
//define as variáveis do objeto e encapsula-as usando private
public class DoadorFinanceiro extends Doador{
    private int idDoadorFinanceiro;
    private String tipo_doador;
      public DoadorFinanceiro( int idDoadorFinanceiro,String cpf, String data_nascimento, String logradouro, 
                            String bairro, String municipio, String unidade_federativa, 
                            String telefone, String tipo_doador) {
        // Chama o construtor da classe mãe (Doador) para inicializar os atributos da classe mãe
        super(cpf, data_nascimento, logradouro, bairro, municipio, unidade_federativa, telefone);
        
        // Inicializa os atributos específicos da classe DoadorFinanceiro
        this.idDoadorFinanceiro = idDoadorFinanceiro;
        this.tipo_doador = tipo_doador;
      }
      public DoadorFinanceiro(String cpf,String data_nascimento, String logradouro, 
                            String bairro, String municipio, String unidade_federativa, 
                            String telefone,String tipo_doador){
          super(cpf, data_nascimento, logradouro, bairro, municipio, unidade_federativa, telefone);
          this.tipo_doador = tipo_doador;
      }
    
    //aplica os métodos getters and setters.
    public int getIdDoadorFinanceiro() {
        return idDoadorFinanceiro;
    }

    public void setIdDoadorFinanceiro(int idDoadorFinanceiro) {
        this.idDoadorFinanceiro = idDoadorFinanceiro;
    }

    public String getTipo_doador() {
        return tipo_doador;
    }

    public void setTipo_doador(String tipo_doador) {
        this.tipo_doador = tipo_doador;
    }
  
    }

