/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.ifsuldeminas.projetodoacaosangue;

/**
 *
 * @author Usuario
 */
public class ProjetoDoacaoSangue {
        
        //TODO:
        // INTERFACE GRÁFICA
        // CONECTAR COM O BANCO DE DADOS  > feito
        // UTILIZAR QUERY PRA CONSULTA DE DADOS
        
    }